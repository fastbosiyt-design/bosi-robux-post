import React, { useState } from 'react';
import { X, Dices, Coins, Box, Sparkles, Loader2, ArrowRight } from 'lucide-react';
import { UserProfile } from '../types';
import { sound } from '../utils/audio';
import { triggerHaptic, triggerHapticSuccess } from '../utils/telegram';

interface MiniGamesModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onPlayGame: (gameType: 'wheel' | 'chests' | 'coinflip', bet: number, choice?: string) => Promise<{
    won: boolean;
    multiplier: number;
    payout: number;
    details: string;
    netProfit: number;
  }>;
}

export const MiniGamesModal: React.FC<MiniGamesModalProps> = ({
  isOpen,
  onClose,
  user,
  onPlayGame,
}) => {
  const [selectedGame, setSelectedGame] = useState<'wheel' | 'chests' | 'coinflip'>('wheel');
  const [bet, setBet] = useState(10);
  const [coinChoice, setCoinChoice] = useState<'heads' | 'tails'>('heads');
  const [selectedChest, setSelectedChest] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [gameResult, setGameResult] = useState<{
    won: boolean;
    multiplier: number;
    payout: number;
    details: string;
    netProfit: number;
  } | null>(null);

  if (!isOpen) return null;

  const quickBets = [5, 10, 25, 50, 100];

  const handlePlay = async (chosenChest?: number) => {
    if (user.balance < bet) {
      alert(`Hisobingizda yetarli Robux yo'q! Hozirda: ${user.balance.toFixed(2)} ta RBX`);
      return;
    }

    setLoading(true);
    setGameResult(null);
    if (chosenChest !== undefined) {
      setSelectedChest(chosenChest);
    }

    try {
      if (selectedGame === 'wheel') {
        sound.playWheelSpin();
      } else if (selectedGame === 'chests') {
        sound.playChestOpen();
      } else if (selectedGame === 'coinflip') {
        sound.playCoinFlip();
      }
      triggerHaptic('medium');

      const res = await onPlayGame(selectedGame, bet, coinChoice);
      setGameResult(res);

      if (res.won) {
        sound.playSuccess();
        triggerHapticSuccess();
      } else {
        sound.playError();
      }
    } catch {
      // error handled
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-950 p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
            <Dices className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Robux Mini-O'yinlar</h2>
            <p className="text-xs text-slate-400">
              O'ynash Robuxlik — yutsangiz ko'paytirib olasiz!
            </p>
          </div>
        </div>

        {/* Balance Display */}
        <div className="p-3 mb-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-400">Mavjud Robuxingiz:</span>
          <span className="font-mono font-bold text-emerald-400 text-sm">
            {user.balance.toFixed(2)} ta RBX
          </span>
        </div>

        {/* Game Mode Selector */}
        <div className="grid grid-cols-3 gap-2 p-1 bg-slate-900 rounded-xl border border-slate-800 mb-5">
          <button
            onClick={() => {
              setSelectedGame('wheel');
              setGameResult(null);
            }}
            className={`py-2 px-1 text-xs font-bold rounded-lg transition-colors cursor-pointer flex flex-col items-center gap-1 ${
              selectedGame === 'wheel' ? 'bg-purple-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="h-4 w-4" />
            <span>Omad Charxi</span>
          </button>

          <button
            onClick={() => {
              setSelectedGame('chests');
              setGameResult(null);
            }}
            className={`py-2 px-1 text-xs font-bold rounded-lg transition-colors cursor-pointer flex flex-col items-center gap-1 ${
              selectedGame === 'chests' ? 'bg-purple-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Box className="h-4 w-4" />
            <span>Sirli Qutilar</span>
          </button>

          <button
            onClick={() => {
              setSelectedGame('coinflip');
              setGameResult(null);
            }}
            className={`py-2 px-1 text-xs font-bold rounded-lg transition-colors cursor-pointer flex flex-col items-center gap-1 ${
              selectedGame === 'coinflip' ? 'bg-purple-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Coins className="h-4 w-4" />
            <span>Tanga (Flip)</span>
          </button>
        </div>

        {/* Bet Selection */}
        <div className="mb-5">
          <label className="block text-xs font-semibold text-slate-300 mb-1.5">
            Tikish Miqdori (Robux):
          </label>
          <div className="grid grid-cols-5 gap-2 mb-2">
            {quickBets.map((b) => (
              <button
                key={b}
                type="button"
                onClick={() => setBet(b)}
                className={`py-1.5 px-1 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                  bet === b
                    ? 'border-purple-500 bg-purple-500/20 text-purple-300'
                    : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-white'
                }`}
              >
                {b} RBX
              </button>
            ))}
          </div>
        </div>

        {/* GAME 1: WHEEL OF FORTUNE */}
        {selectedGame === 'wheel' && (
          <div className="p-4 rounded-2xl border border-slate-800 bg-slate-900/40 text-center mb-5">
            <div className="py-4">
              <div className="inline-block p-4 rounded-full border-4 border-dashed border-purple-500/40 bg-purple-950/20 mb-3 animate-spin-slow">
                <Sparkles className="h-10 w-10 text-purple-400" />
              </div>
              <h3 className="text-sm font-bold text-white mb-1">Omad Charxini Aylantirish</h3>
              <p className="text-xs text-slate-400 max-w-xs mx-auto mb-4">
                Yutuqlar: 0x, 0.5x, 1.5x, 2x, 2.5x, 5x, 10x gacha Robux ko'paytmasi!
              </p>

              <button
                onClick={() => handlePlay()}
                disabled={loading || user.balance < bet}
                className="py-3 px-6 rounded-xl font-bold text-xs bg-purple-500 hover:bg-purple-400 text-slate-950 shadow-lg shadow-purple-500/20 transition-all cursor-pointer active:scale-95 disabled:opacity-50"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin mx-auto" /> : `Aylantirish (${bet} RBX)`}
              </button>
            </div>
          </div>
        )}

        {/* GAME 2: MYSTERY CHESTS */}
        {selectedGame === 'chests' && (
          <div className="p-4 rounded-2xl border border-slate-800 bg-slate-900/40 text-center mb-5">
            <h3 className="text-sm font-bold text-white mb-1">3 ta Sandiqdan Birini Tanlang</h3>
            <p className="text-xs text-slate-400 mb-4">
              Birida 0x, ikkitasida 1.8x va 3.5x Robux yashiringan!
            </p>

            <div className="grid grid-cols-3 gap-3 mb-4">
              {[0, 1, 2].map((idx) => (
                <button
                  key={idx}
                  onClick={() => handlePlay(idx)}
                  disabled={loading || user.balance < bet}
                  className={`p-4 rounded-xl border border-slate-800 bg-slate-900/80 hover:border-purple-500/60 hover:scale-105 transition-all flex flex-col items-center gap-2 cursor-pointer ${
                    selectedChest === idx && loading ? 'ring-2 ring-purple-400' : ''
                  }`}
                >
                  <Box className="h-8 w-8 text-amber-400" />
                  <span className="text-[11px] font-bold text-slate-200">Sandiq #{idx + 1}</span>
                </button>
              ))}
            </div>
            <p className="text-[11px] text-slate-500">Tikish miqdori: {bet} RBX</p>
          </div>
        )}

        {/* GAME 3: COIN FLIP */}
        {selectedGame === 'coinflip' && (
          <div className="p-4 rounded-2xl border border-slate-800 bg-slate-900/40 text-center mb-5">
            <h3 className="text-sm font-bold text-white mb-1">Burgut yoki Raqam (50/50)</h3>
            <p className="text-xs text-slate-400 mb-4">
              To'g'ri topsangiz 1.95x yutuq olasiz!
            </p>

            <div className="grid grid-cols-2 gap-3 mb-4 max-w-xs mx-auto">
              <button
                type="button"
                onClick={() => setCoinChoice('heads')}
                className={`py-3 px-4 rounded-xl border font-bold text-xs transition-all cursor-pointer ${
                  coinChoice === 'heads'
                    ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300 ring-2 ring-emerald-500/30'
                    : 'border-slate-800 bg-slate-900 text-slate-400'
                }`}
              >
                🦅 Burgut
              </button>

              <button
                type="button"
                onClick={() => setCoinChoice('tails')}
                className={`py-3 px-4 rounded-xl border font-bold text-xs transition-all cursor-pointer ${
                  coinChoice === 'tails'
                    ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300 ring-2 ring-emerald-500/30'
                    : 'border-slate-800 bg-slate-900 text-slate-400'
                }`}
              >
                🪙 Raqam
              </button>
            </div>

            <button
              onClick={() => handlePlay()}
              disabled={loading || user.balance < bet}
              className="py-3 px-6 rounded-xl font-bold text-xs bg-emerald-400 hover:bg-emerald-300 text-slate-950 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer active:scale-95 disabled:opacity-50"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin mx-auto" /> : `Tashlash (${bet} RBX)`}
            </button>
          </div>
        )}

        {/* Game Result Banner */}
        {gameResult && (
          <div
            className={`p-4 rounded-xl border text-center animate-in zoom-in-95 duration-200 ${
              gameResult.won
                ? 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300'
                : 'border-red-800 bg-red-950/20 text-red-300'
            }`}
          >
            <div className="text-base font-black mb-1">
              {gameResult.won ? '🎉 YUTDINGIZ!' : '😔 YUTQAZDINGIZ'}
            </div>
            <p className="text-xs mb-1">{gameResult.details}</p>
            <div className="font-mono text-sm font-bold">
              {gameResult.won ? (
                <span>+{gameResult.payout.toFixed(2)} ta RBX (Foyda: +{gameResult.netProfit.toFixed(2)} RBX)</span>
              ) : (
                <span>-{bet} ta RBX</span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
