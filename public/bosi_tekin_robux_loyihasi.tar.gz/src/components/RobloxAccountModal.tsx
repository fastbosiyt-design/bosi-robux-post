import React, { useState } from 'react';
import { Gamepad2, CheckCircle2, AlertCircle, Loader2, Sparkles, X } from 'lucide-react';
import { sound } from '../utils/audio';
import { triggerHapticSuccess } from '../utils/telegram';

interface RobloxAccountModalProps {
  isOpen: boolean;
  onClose?: () => void;
  canClose?: boolean;
  onLinkRoblox: (nickname: string) => Promise<{ success: boolean; message?: string; error?: string; avatarUrl?: string }>;
}

export const RobloxAccountModal: React.FC<RobloxAccountModalProps> = ({
  isOpen,
  onClose,
  canClose = true,
  onLinkRoblox,
}) => {
  const [nickname, setNickname] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [previewAvatar, setPreviewAvatar] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleNicknameChange = (val: string) => {
    setNickname(val);
    setErrorMsg('');
    if (val.trim().length >= 3) {
      setPreviewAvatar(`https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(val.trim())}&backgroundColor=0f172a`);
    } else {
      setPreviewAvatar(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const cleanNick = nickname.trim();
    if (cleanNick.length < 3) {
      setErrorMsg('Roblox foydalanuvchi nomi kamida 3 ta belgidan iborat bo\'lishi shart!');
      return;
    }

    setLoading(true);
    try {
      const res = await onLinkRoblox(cleanNick);
      if (res.success) {
        sound.playSuccess();
        triggerHapticSuccess();
        setSuccessMsg(`O'yinchi topildi! ${cleanNick} akkaunti muvaffaqiyatli bog'landi va eslab qolindi.`);
        setTimeout(() => {
          if (onClose) onClose();
        }, 1500);
      } else {
        setErrorMsg(res.error || 'Ushbu nikli odam allaqachon mavjud! Boshqa nik tanlang.');
      }
    } catch (err: unknown) {
      if (err instanceof Error) {
        setErrorMsg(err.message);
      } else {
        setErrorMsg('Xatolik yuz berdi');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-950 p-6 shadow-2xl relative">
        {canClose && onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        )}

        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <Gamepad2 className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Roblox Akkauntini Bog'lash</h2>
            <p className="text-xs text-slate-400">
              Nikingiz eslab qolinadi va boshqa hech qachon so'ralmaydi
            </p>
          </div>
        </div>

        {/* Security Notice: No Password Required */}
        <div className="p-3 mb-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
          <p className="flex items-center gap-1.5 font-semibold text-emerald-400 mb-0.5">
            <Sparkles className="h-4 w-4" />
            <span>Parol umuman kerak emas!</span>
          </p>
          <p className="text-slate-400">
            Faqat Roblox foydalanuvchi nomingizni (nikingizni) yozing. Sayt va bot bu nikni sizga biriktiradi va boshqa hech kim bu nik bilan kira olmaydi.
          </p>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/40 border border-red-800 text-xs text-red-300 flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-950/40 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Roblox Nikingiz (Username):
            </label>
            <div className="flex items-center gap-3">
              <input
                type="text"
                required
                placeholder="Masalan: ProGamer_2026"
                value={nickname}
                onChange={(e) => handleNicknameChange(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 font-medium"
              />

              {previewAvatar && (
                <div className="h-11 w-11 shrink-0 rounded-xl border border-emerald-500/50 bg-slate-900 p-1 overflow-hidden shadow-md">
                  <img src={previewAvatar} alt="Avatar" className="h-full w-full object-cover rounded-lg" />
                </div>
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Topilgach sizning avataringiz va nikingiz doimiy saqlanadi.
            </p>
          </div>

          <button
            type="submit"
            disabled={loading || nickname.trim().length < 3}
            className="w-full py-3 px-4 rounded-xl font-bold text-xs bg-emerald-400 hover:bg-emerald-300 disabled:opacity-50 text-slate-950 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/20 active:scale-95"
          >
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                <CheckCircle2 className="h-4 w-4" />
                <span>Akkauntni Tekshirish va Saqlash</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
